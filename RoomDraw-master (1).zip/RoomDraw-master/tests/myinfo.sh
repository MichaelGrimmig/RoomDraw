#!/bin/sh

. ./common.sh

GET /myinfo $@
echo
