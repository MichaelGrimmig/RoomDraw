#!/bin/sh

. ./common.sh
DELETE "/group" $@
