#!/bin/sh

. ./common.sh

DELETE /wishlist?rank=1 $@
echo
