#!/bin/sh

. ./common.sh

GET /group $@
echo
