#!/bin/sh

. ./common.sh

GET /wishlist $@
echo
