#!/bin/sh

. ./common.sh

GET /dorms?dorm=a $@
echo
