#!/bin/sh

. ./common.sh

GET /group/members $@
echo
