#!/bin/sh

. ./common.sh

DELETE /group_wishlist?rank=
