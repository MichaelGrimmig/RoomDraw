#!/usr/bin/python

sql_host = "localhost"
sql_user = "root"
sql_password = "RoomDraw2018"
sql_db = "RoomDrawTesting"
