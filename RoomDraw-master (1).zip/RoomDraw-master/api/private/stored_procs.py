#!/usr/bin/python

get_student = "GetStudent"
get_group = "GetGroupInfo"
get_group_members = "GetGroupMembers"
leave_group = "LeaveGroup"
get_single_dorm = "GetDorm"
get_dorms = "GetDorms"

get_rooms = "GetRooms"

get_group_wishlist = "GetGroupWishlist"
delete_group_wishlist = "DeleteGroupWishlist"
put_group_wishlist = "AddGroupWishlist"

get_student_wishlist = "GetStudentWishlist"
delete_student_wishlist = "DeleteStudentWishlist"
put_student_wishlist = "AddStudentWishlist"
